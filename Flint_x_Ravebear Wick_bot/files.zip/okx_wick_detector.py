"""
OKX WebSocket Wick Detector - First Run Version
================================================

REQUIREMENTS (install these first):
    pip install websockets asyncio

WHAT THIS DOES:
    1. Connects to OKX WebSocket
    2. Streams 1-minute candlesticks
    3. Detects 5 consecutive wicks
    4. Logs everything in real-time

USAGE:
    python okx_wick_detector.py

DEFAULT SYMBOL: ETH-USDT (better for altseason)
Change symbol in main() if needed
"""

import asyncio
import json
import websockets
import sqlite3
from datetime import datetime


class OKXWickDetector:
    def __init__(self, symbol="BTC-USDT"):
        self.symbol = symbol
        self.ws_url = "wss://ws.okx.com:8443/ws/v5/public"
        self.wick_history = []
        self.candle_count = 0
        self.db_path = "wick_data.db"
        self.init_database()
    
    def init_database(self):
        """Create SQLite database and wicks table"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS wicks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                symbol TEXT NOT NULL,
                open REAL NOT NULL,
                high REAL NOT NULL,
                low REAL NOT NULL,
                close REAL NOT NULL,
                upper_wick REAL NOT NULL,
                lower_wick REAL NOT NULL,
                body REAL NOT NULL,
                wick_type TEXT NOT NULL,
                sequence_position INTEGER,
                touched INTEGER DEFAULT 0,
                touched_at TEXT,
                touch_price REAL,
                touch_candle_timestamp TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        conn.commit()
        conn.close()
        print(f"✅ Database initialized: {self.db_path}")
    
    def save_wick(self, wick_data, sequence_position=None):
        """Save wick to SQLite database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO wicks (
                    timestamp, symbol, open, high, low, close,
                    upper_wick, lower_wick, body, wick_type, sequence_position
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                wick_data['timestamp'],
                self.symbol,
                wick_data['open'],
                wick_data['high'],
                wick_data['low'],
                wick_data['close'],
                wick_data['upper_wick'],
                wick_data['lower_wick'],
                wick_data['body'],
                wick_data['wick_type'],
                sequence_position
            ))
            
            conn.commit()
            conn.close()
            print(f"   💾 Saved to database (ID: {cursor.lastrowid})")
            return True
            
        except Exception as e:
            print(f"   ❌ Database save failed: {e}")
            return False
    
    def check_tip_touches(self, current_candle_data):
        """
        Check if current candle touches any previous wick tips
        This is the TIP-TO-TIP pattern - exact price matching
        """
        try:
            timestamp = current_candle_data[0]
            current_high = float(current_candle_data[2])
            current_low = float(current_candle_data[3])
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get all untouched wicks
            cursor.execute('''
                SELECT id, timestamp, high, low, wick_type 
                FROM wicks 
                WHERE touched = 0 
                AND symbol = ?
            ''', (self.symbol,))
            
            untouched_wicks = cursor.fetchall()
            
            if not untouched_wicks:
                conn.close()
                return
            
            # Tolerance: $0.50 for tip matching
            tolerance = 0.50
            
            for wick_id, wick_timestamp, wick_high, wick_low, wick_type in untouched_wicks:
                touched = False
                touch_price = None
                
                # Check if current candle touches this wick's tip
                if abs(current_high - wick_high) <= tolerance:
                    touched = True
                    touch_price = wick_high
                    touch_type = "HIGH"
                elif abs(current_low - wick_low) <= tolerance:
                    touched = True
                    touch_price = wick_low
                    touch_type = "LOW"
                
                if touched:
                    # Update database
                    current_timestamp = datetime.fromtimestamp(int(timestamp) / 1000).strftime('%Y-%m-%d %H:%M:%S')
                    
                    cursor.execute('''
                        UPDATE wicks 
                        SET touched = 1,
                            touched_at = ?,
                            touch_price = ?,
                            touch_candle_timestamp = ?
                        WHERE id = ?
                    ''', (current_timestamp, touch_price, current_timestamp, wick_id))
                    
                    conn.commit()
                    
                    # Alert
                    print("\n" + "🎯" * 30)
                    print(f"⚡ TIP-TO-TIP TOUCHER DETECTED!")
                    print(f"   Original Wick: {wick_timestamp} ({wick_type})")
                    print(f"   Touch Point: ${touch_price:.2f} ({touch_type})")
                    print(f"   Time Since: {current_timestamp}")
                    print(f"   Database ID: {wick_id}")
                    print("🎯" * 30 + "\n")
            
            conn.close()
            
        except Exception as e:
            print(f"❌ Tip-touch check failed: {e}")
        
    def calculate_wick_stats(self, candle_data):
        """
        Extract wick information from candle
        Returns: (has_wick, upper_wick, lower_wick, wick_type)
        """
        try:
            # OKX candle format: [ts, open, high, low, close, vol, volCcy, volCcyQuote, confirm]
            timestamp = candle_data[0]
            open_price = float(candle_data[1])
            high = float(candle_data[2])
            low = float(candle_data[3])
            close = float(candle_data[4])
            
            # Determine candle direction
            is_bullish = close > open_price
            
            # Calculate wicks
            if is_bullish:
                upper_wick = high - close
                lower_wick = open_price - low
            else:
                upper_wick = high - open_price
                lower_wick = close - low
            
            # Body size
            body = abs(close - open_price)
            
            # Has significant wick if either wick > 20% of body
            has_wick = (upper_wick > body * 0.2) or (lower_wick > body * 0.2)
            
            # Wick type
            wick_type = None
            if has_wick:
                if upper_wick > lower_wick:
                    wick_type = "UPPER"
                else:
                    wick_type = "LOWER"
            
            return {
                'timestamp': datetime.fromtimestamp(int(timestamp) / 1000).strftime('%Y-%m-%d %H:%M:%S'),
                'has_wick': has_wick,
                'upper_wick': round(upper_wick, 2),
                'lower_wick': round(lower_wick, 2),
                'body': round(body, 2),
                'wick_type': wick_type,
                'high': high,
                'low': low,
                'open': open_price,
                'close': close
            }
            
        except Exception as e:
            print(f"❌ Error calculating wick: {e}")
            return None
    
    def check_consecutive_wicks(self, wick_data):
        """Track and detect 5 consecutive wicks"""
        if wick_data and wick_data['has_wick']:
            self.wick_history.append(wick_data)
            
            # Save to database with sequence position
            sequence_pos = len(self.wick_history)
            self.save_wick(wick_data, sequence_pos)
            
            # Keep only last 5
            if len(self.wick_history) > 5:
                self.wick_history.pop(0)
            
            # Check if we have 5 consecutive wicks
            if len(self.wick_history) == 5:
                print("\n" + "="*60)
                print("🎯 5 CONSECUTIVE WICKS DETECTED!")
                print("="*60)
                for i, wick in enumerate(self.wick_history, 1):
                    print(f"  {i}. {wick['timestamp']} | {wick['wick_type']} | Upper: {wick['upper_wick']} | Lower: {wick['lower_wick']}")
                print("="*60 + "\n")
                
                # Reset after detection
                self.wick_history = []
        else:
            # Reset if no wick detected
            if self.wick_history:
                print(f"⚠️  Wick sequence broken. Had {len(self.wick_history)} wicks, resetting...")
            self.wick_history = []
    
    async def health_check(self):
        """Test connection before main loop"""
        print("\n⚡ HEALTH CHECK")
        print("-" * 40)
        try:
            async with websockets.connect(self.ws_url, ping_interval=20) as ws:
                print("✅ WebSocket connection successful")
                
                # Test ping
                ping_msg = {"op": "ping"}
                await ws.send(json.dumps(ping_msg))
                response = await asyncio.wait_for(ws.recv(), timeout=5)
                print(f"✅ Ping response: {response}")
                
                return True
        except Exception as e:
            print(f"❌ Health check failed: {e}")
            return False
    
    async def connect_and_stream(self):
        """Main WebSocket loop"""
        print(f"\n⚡ CONNECTING TO OKX")
        print(f"   Symbol: {self.symbol}")
        print(f"   Timeframe: 1 minute")
        print("-" * 40)
        
        async with websockets.connect(self.ws_url, ping_interval=20) as ws:
            # Subscribe to 1m candles
            subscribe_msg = {
                "op": "subscribe",
                "args": [
                    {
                        "channel": "candle1m",
                        "instId": self.symbol
                    }
                ]
            }
            
            await ws.send(json.dumps(subscribe_msg))
            print(f"✅ Subscribed to {self.symbol} 1m candles")
            print("✅ Streaming live data...\n")
            
            # Listen for messages
            while True:
                try:
                    message = await ws.recv()
                    data = json.loads(message)
                    
                    # Handle subscription confirmation
                    if 'event' in data:
                        if data['event'] == 'subscribe':
                            print(f"✅ Subscription confirmed: {data['arg']}")
                        continue
                    
                    # Handle candle data
                    if 'data' in data:
                        for candle in data['data']:
                            self.candle_count += 1
                            
                            # Check for tip touches FIRST (before wick detection)
                            self.check_tip_touches(candle)
                            
                            # Then detect wicks
                            wick_data = self.calculate_wick_stats(candle)
                            
                            if wick_data:
                                # Print candle info
                                status = "🔥 WICK" if wick_data['has_wick'] else "📊 No wick"
                                print(f"{status} | {wick_data['timestamp']} | O:{wick_data['open']} H:{wick_data['high']} L:{wick_data['low']} C:{wick_data['close']}")
                                
                                if wick_data['has_wick']:
                                    print(f"   └─ {wick_data['wick_type']} wick | Upper: {wick_data['upper_wick']} | Lower: {wick_data['lower_wick']} | Sequence: {len(self.wick_history) + 1}/5")
                                
                                # Check for 5 consecutive
                                self.check_consecutive_wicks(wick_data)
                
                except websockets.exceptions.ConnectionClosed:
                    print("❌ Connection closed, reconnecting...")
                    await asyncio.sleep(2)
                    break
                except Exception as e:
                    print(f"❌ Error: {e}")
                    await asyncio.sleep(1)


async def main():
    """
    Main entry point
    
    To change symbol, modify this line:
    detector = OKXWickDetector("BTC-USDT")
    
    Or any other pair: "SOL-USDT", "AVAX-USDT", etc.
    """
    
    print("\n" + "="*60)
    print("    OKX WICK DETECTOR - FIRST RUN")
    print("="*60)
    
    # Initialize detector
    detector = OKXWickDetector("ETH-USDT")
    
    # Run health check
    if not await detector.health_check():
        print("\n❌ Health check failed. Exiting.")
        return
    
    print("\n✅ Health check passed. Starting main stream...\n")
    
    # Start main loop
    try:
        await detector.connect_and_stream()
    except KeyboardInterrupt:
        print("\n\n⚠️  Stopped by user")
        print(f"📊 Total candles processed: {detector.candle_count}")


if __name__ == "__main__":
    asyncio.run(main())
